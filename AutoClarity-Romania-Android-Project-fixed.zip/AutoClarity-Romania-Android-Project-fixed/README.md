# AutoClarity România

Free starter Android app for Romanian drivers.

Build with JDK 17 and Android Gradle Plugin 8.7.3.
