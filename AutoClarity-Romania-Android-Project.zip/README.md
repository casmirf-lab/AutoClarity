# AutoClarity România

Free starter Android app for Romanian drivers.

Features:
- Shortcuts to official RCA (BAAR/AIDA), ITP (RAR), and rovinieta (CNAIR/eRovinieta) checks.
- Links to Romanian RCA quote/comparison services.
- Local-only vehicle plate/VIN and expiry-date notes.
- Simple remaining-days display.

Important limitations:
- It does NOT scrape official sites, bypass CAPTCHA, or claim live verification inside the app.
- The official checks open in the browser; users complete each official form themselves.
- Expiry dates entered by the user are reminders, not official status checks.
- Insurance quote links are third-party broker services. Verify final price and broker/insurer details before purchase.

Build with JDK 17 and Android Gradle Plugin 8.7.3.
